const karthi = () => {
    console.log("Hello Node.js!");
    };
    
    karthi();